%XYZLABEL Label X, Y and Z axes
%
% XYZLABEL label the x-, y- and z-axes with 'X', 'Y', and 'Z' 
% respectiveley
function xyzlabel
    xlabel('x');
    ylabel('y');
    zlabel('z');
